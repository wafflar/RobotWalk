

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * テストクラス RobotTest.
 *
 * @author (あなたの名前)
 * @version (バージョン番号もしくは日付)
 */
public class RobotTest
{
    /**
     * テストクラス RobotTest のためのデフォルトのコンストラクタ
     */
    public RobotTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void RobotWalk_Test()
    {
        Robot robot1 = new Robot();
        assertEquals(30, robot1.RobotWalk("녹색", 30), 0.0);
        assertEquals(36.0, robot1.RobotWalk("노란색", 30), 0.0);
        assertEquals(0.0, robot1.RobotWalk("빨간색", 30), 0.0);
    }
}

